gcc ildar.c -shared -fPIC -o integerset.so 
