gcc echo.c -shared -fPIC -o core.so
