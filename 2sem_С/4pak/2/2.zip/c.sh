gcc main.c matrixsqr.c libopenblas.so -o checked_solution -lpthread
