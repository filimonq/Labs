gcc -c level1.c level2.c level3.c 
ar rcs myblas.a level1.o level2.o level3.o
